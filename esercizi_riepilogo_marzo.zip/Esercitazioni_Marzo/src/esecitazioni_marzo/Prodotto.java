package esecitazioni_marzo;

class Prodotto {
	/* attributes */
	private String nome;
	private double peso;
	private double prezzo;
	
	/* constructor*/
	public Prodotto(String nome, double prezzo, double peso) {
		this.nome = nome;
		this.prezzo = prezzo;
		this.peso = peso;
	}

	/* methods */
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getPrezzo() {
		return prezzo;
	}

	public void setPrezzo(double prezzo) {
		this.prezzo = prezzo;
	}

}
