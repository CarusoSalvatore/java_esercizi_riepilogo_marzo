package esecitazioni_marzo;

class PokemonFuoco extends Pokemon{
	/* attributes */
	private int temperature;
	
	/* constructor */
	PokemonFuoco(String nome, String tipo, int livello, int attacco, int difesa, int attacco_speciale, int difesa_speciale, int temperature){
		super(nome,  tipo, livello, attacco, difesa, attacco_speciale, difesa_speciale);
		this.temperature = temperature;
	}

	/* methods */
	public int getTemperature() {
		return temperature;
	}

	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}
	
	public void lanciaFiamme() {
		System.out.println("Hai incenerito il pokemon avversario");
	}

}
