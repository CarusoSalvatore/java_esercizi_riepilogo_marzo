package esecitazioni_marzo;

import java.util.*;

class sortByScore implements Comparator<Carico>{
	public int compare(Carico c_1, Carico c_2) {
		return Double.compare(c_2.getValutazione_punteggio(), c_1.getValutazione_punteggio());
	}
}

class Carico{
	/* attributes */
	private ArrayList<Double> pesi;
	private ArrayList<Double> prezzi;
	double limite_peso;
	double valutazione_punteggio;
	double peso_usato;
	int generazione;
	private ArrayList<Integer> cromosoma;
	
	/* constructor */
	public Carico(ArrayList<Double> prezzi, ArrayList<Double> pesi, double limite_peso) {
		this.prezzi = prezzi;
		this.pesi = pesi;
		this.limite_peso = limite_peso;
		valutazione_punteggio = 0;
		peso_usato = 0;
		generazione = 0;
		
		for(int i = 0; i < pesi.size(); i++) {
			double valore = Math.random();
			if(valore < 0.5) {
				this.cromosoma.add(0);
			}
			else {
				this.cromosoma.add(1);
			}
			
		}
	}

	/* methods */
	public void fitness() {
		double punteggio = 0;
		double somma_pesi = 0;
		
		for(int i = 0; i < this.cromosoma.size(); i++) {
			if(this.cromosoma.get(i) == 1) {
				punteggio += this.prezzi.get(i);
				somma_pesi += this.pesi.get(i);
			}
			if (somma_pesi > this.limite_peso) {
				punteggio = 0.1;
			}
		}
		
		this.valutazione_punteggio = punteggio;
		this.peso_usato = somma_pesi;
	}
	//----------------------------------------------------------------------------
	public void advanceGeneration() {
		this.generazione += 1; 
	}
	//----------------------------------------------------------------------------
	public ArrayList<Carico> crossover(Carico altro_carico){
		double valore_cutoff = Math.random();
		int cutoff = (int) valore_cutoff*this.cromosoma.size();
		ArrayList<Integer> child_1_cromosoma = new ArrayList<Integer>();
		ArrayList<Integer> child_2_cromosoma = new ArrayList<Integer>();
		
		for(int i = 0; i < cutoff; i++) {
			child_1_cromosoma.add(altro_carico.getCromosoma().get(i));
			child_2_cromosoma.add(this.cromosoma.get(i));
		}
		
		for(int i = cutoff; i < child_1_cromosoma.size(); i++) {
			child_1_cromosoma.add(this.cromosoma.get(i));
			child_2_cromosoma.add(altro_carico.getCromosoma().get(i));
		}
		
		Carico child_1 = new Carico(this.prezzi, this.pesi, this.limite_peso);
		Carico child_2 = new Carico(this.prezzi, this.pesi, this.limite_peso);
		
		child_1.advanceGeneration();
		child_2.advanceGeneration();
		
		child_1.setCromosoma(child_1_cromosoma);
		child_2.setCromosoma(child_2_cromosoma);
		
		ArrayList<Carico> children = new ArrayList<Carico>();
		children.add(child_1);
		children.add(child_2);
		
		return children;
	}
	//----------------------------------------------------------------------------
	public void mutation(double rate) {
		for(int i = 0; i < this.cromosoma.size(); i++) {
			if(Math.random() < rate) {
				if(this.cromosoma.get(i) == 1) {
					this.cromosoma.set(i, 0);
				}
				else {
					this.cromosoma.set(i, 1);
				}
			}
		}
	}
	//----------------------------------------------------------------------------
	public ArrayList<Double> getPesi() {
		return pesi;
	}
	//----------------------------------------------------------------------------
	public void setPesi(ArrayList<Double> pesi) {
		this.pesi = pesi;
	}
	//----------------------------------------------------------------------------
	public ArrayList<Double> getPrezzi() {
		return prezzi;
	}
	//----------------------------------------------------------------------------
	public void setPrezzi(ArrayList<Double> prezzi) {
		this.prezzi = prezzi;
	}
	//----------------------------------------------------------------------------
	public double getLimite_peso() {
		return limite_peso;
	}
	//----------------------------------------------------------------------------
	public void setLimite_peso(double limite_peso) {
		this.limite_peso = limite_peso;
	}
	//----------------------------------------------------------------------------
	public double getValutazione_punteggio() {
		return valutazione_punteggio;
	}
	//----------------------------------------------------------------------------
	public void setValutazione_punteggio(double valutazione_punteggio) {
		this.valutazione_punteggio = valutazione_punteggio;
	}
	//----------------------------------------------------------------------------
	public double getPeso_usato() {
		return peso_usato;
	}
	//----------------------------------------------------------------------------
	public void setPeso_usato(double peso_usato) {
		this.peso_usato = peso_usato;
	}
	//----------------------------------------------------------------------------
	public int getGenerazione() {
		return generazione;
	}
	//----------------------------------------------------------------------------
	public void setGenerazione(int generazione) {
		this.generazione = generazione;
	}
	//----------------------------------------------------------------------------
	public ArrayList<Integer> getCromosoma() {
		return cromosoma;
	}
	//----------------------------------------------------------------------------
	public void setCromosoma(ArrayList<Integer> cromosoma) {
		this.cromosoma = cromosoma;
	}
	
	

}
