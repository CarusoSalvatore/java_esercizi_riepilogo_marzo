package esecitazioni_marzo;

import java.util.*;

class SortbyLevel implements Comparator<Pokemon>
{
    // Used for sorting in decending order of
    // roll number
    public int compare(Pokemon a, Pokemon b)
    {
        return b.getLivello() - a.getLivello();
    }
}

class SortbyAttack implements Comparator<Pokemon>{
	public int compare(Pokemon a, Pokemon b) {
		return b.getAttacco() - a.getAttacco();
	}
}

class Pokemon {
	/* attributes */
	protected String nome;
	protected String tipo;
	protected int livello;
	protected int attacco;
	protected int difesa;
	protected int attacco_speciale;
	protected int difesa_speciale;
	
	/* constructor */
	public Pokemon(String nome, String tipo, int livello, int attacco, int difesa, int attacco_speciale, int difesa_speciale) {
		if(livello <= 0 || livello > 100) {
			throw new IllegalArgumentException("Livello inserito non valido.");
		}
		this.nome = nome;
		this.tipo = tipo;
		this.livello = livello;
		this.attacco = attacco; 
		this.difesa = difesa;
		this.attacco_speciale = attacco_speciale; 
		this.difesa_speciale = difesa_speciale; 
	}
	
	/* methods */
	void aumentaLivello() {
		this.livello = this.livello + 1;
		this.attacco += 2;
		this.difesa += 2;
		this.attacco_speciale += 2;
		this.difesa_speciale += 2;
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public int getAttacco() {
		return attacco;
	}

	public void setAttacco(int attacco) {
		this.attacco = attacco;
	}

	public int getDifesa() {
		return difesa;
	}

	public void setDifesa(int difesa) {
		this.difesa = difesa;
	}

	public int getAttacco_speciale() {
		return attacco_speciale;
	}

	public void setAttacco_speciale(int attacco_speciale) {
		this.attacco_speciale = attacco_speciale;
	}

	public int getDifesa_speciale() {
		return difesa_speciale;
	}

	public void setDifesa_speciale(int difesa_speciale) {
		this.difesa_speciale = difesa_speciale;
	}

	public int getLivello() {
		return livello;
	}

	public void setLivello(int livello) {
		this.livello = livello;
	}
	
	

}
