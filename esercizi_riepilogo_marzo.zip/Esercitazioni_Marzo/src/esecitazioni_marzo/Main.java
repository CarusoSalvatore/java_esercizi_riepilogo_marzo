package esecitazioni_marzo;

import java.util.*;

public class Main {
	public static void main(String[] args) {
		double[] vettore = {1,2,3,4,5,6};
		ArrayList<Double> vettore_array_list = new ArrayList<Double>();
		vettore_array_list.add(4.5);
		vettore_array_list.add(12.0);
		vettore_array_list.add(453.3);
		vettore_array_list.add(4.5);
		vettore_array_list.add(9009.2);
		
		double media = MediaArray.MediaArrayList(vettore_array_list);
		System.out.println("La media �: " + media);
	}

}
