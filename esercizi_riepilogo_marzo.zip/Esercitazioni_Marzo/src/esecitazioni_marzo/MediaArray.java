package esecitazioni_marzo;

import java.util.*;

class MediaArray {
	public static double MediaArrayPreimpostato(double[] array ) {
		double sum = 0;
		for(int i = 0; i < array.length; i++) {
			sum += array[i]; 
		}
		return sum/array.length;
	}
	
	public static double MediaArrayList(ArrayList<Double> array) {
		double sum = 0;
		for(int i = 0; i < array.size(); i++) {
			sum += array.get(i);
		}
		return sum/array.size();

	}
	
	public static double MediaArrayTastiera() {
		Scanner scanner  = new Scanner(System.in);
		System.out.println("Inserisci dei double. Per calcolare la media inserisci un carattere.");
		double somma = 0;
		int contatore = 0;
		while(scanner.hasNextDouble()) {
			double valore = scanner.nextDouble();
			somma += valore;
			contatore += 1;
		}
		return somma/contatore;
		
	}
	
	

}
