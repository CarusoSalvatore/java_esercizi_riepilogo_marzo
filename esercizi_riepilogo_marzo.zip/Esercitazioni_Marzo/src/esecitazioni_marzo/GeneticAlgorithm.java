package esecitazioni_marzo;

import java.util.*;

class GeneticAlgorithm {
	/* attributes */
	private int population_size;
	private ArrayList<Carico> popolazione = new ArrayList<Carico>();
	private int generazione;
	private Carico best_solution;
	private ArrayList<Double> list_of_solutions = new ArrayList<Double>();
	
	/* constructor */
	public GeneticAlgorithm(int population_size) {
		this.population_size = population_size;
		this.generazione = 0;
		this.best_solution = null;
		
	}
	
	/* methods */
	//-----------------------------------------------------------------------------------------------------
	public void initilize_population(ArrayList<Double> prezzi, ArrayList<Double> pesi, double limite_peso) {
		for(int i = 0; i < this.population_size; i++) {
			this.popolazione.add(new Carico(prezzi, pesi, limite_peso));
		}
		this.best_solution = this.popolazione.get(0);
	}
	//-----------------------------------------------------------------------------------------------------
	public void sortPopulation() {
		Collections.sort(this.popolazione, new sortByScore());
	}
	//-----------------------------------------------------------------------------------------------------
	public void best_carico(Carico carico_di_confronto) {
		if(carico_di_confronto.getValutazione_punteggio() > this.best_solution.getValutazione_punteggio()) {
			this.best_solution = carico_di_confronto; 
		}
	}
	//-----------------------------------------------------------------------------------------------------
	public double somma_valutazioni_punteggi() {
		double somma = 0;
		for(int i = 0; i < this.population_size; i++) {
			somma += this.popolazione.get(i).getValutazione_punteggio();
		}
		return somma;
	}
	//-----------------------------------------------------------------------------------------------------
	public int select_parent(double somma_valutazioni_punteggi) {
		int parent = -1;
		double random_value = Math.random()*somma_valutazioni_punteggi;
		double sum = 0;
		int i = 0;
		while(i < this.population_size && sum < random_value) {
			sum += this.popolazione.get(i).getValutazione_punteggio();
			parent += 1;
			i += 1;
		}
		return parent;
	}
	//-----------------------------------------------------------------------------------------------------
	public void visualize_generation() {
		Carico best = this.popolazione.get(0);
		System.out.println("Generazione: " + best.getGenerazione() + ", Total price: " + best.getValutazione_punteggio() + 
				", Weight: " + best.peso_usato + " Chromosome: " + best.getCromosoma());
	}
	//-----------------------------------------------------------------------------------------------------
	public ArrayList<Integer> solve(double mutation_probability, int number_of_generations, ArrayList<Double> prezzi, ArrayList<Double> pesi, double limite_peso){
		this.initilize_population(prezzi, pesi, limite_peso);
		
		for(int i = 0; i < this.population_size; i++) {
			this.popolazione.get(i).fitness();
		}
		
		this.sortPopulation();
		this.best_solution = this.popolazione.get(0);
		this.list_of_solutions.add(this.best_solution.getValutazione_punteggio());
		
		this.visualize_generation();
		
		for(int i = 0; i < number_of_generations; i++) {
			double somma = this.somma_valutazioni_punteggi();
			ArrayList<Carico> new_population = new ArrayList<Carico>();
			
			for(int j = 0; j < this.population_size; j = j + 2) {
				int index_parent_1 = this.select_parent(somma);
				int index_parent_2 = this.select_parent(somma);
				ArrayList<Carico> children = this.popolazione.get(index_parent_1).crossover(this.popolazione.get(index_parent_2));
				children.get(0).mutation(mutation_probability);
				children.get(1).mutation(mutation_probability);
				new_population.add(children.get(0));
				new_population.add(children.get(1));
			}
			
			this.popolazione = new_population;
			
			for(int k = 0; k < this.population_size; k++) {
				this.popolazione.get(k).fitness();
			}
			
			this.visualize_generation();
			Carico best_carico_individuale = this.popolazione.get(0);
			this.list_of_solutions.add(best_carico_individuale.getValutazione_punteggio());
			this.best_carico(best_carico_individuale);
		}
		
		System.out.println("******************");
		System.out.println("Best solution - generation: " + this.best_solution.getGenerazione());
		System.out.println("Best solution - total price: " + this.best_solution.getValutazione_punteggio());
		System.out.println("Best solution - total weight: " + this.best_solution.getPeso_usato());
		System.out.println("Best solution - chromosome: " + this.best_solution.getCromosoma());
		System.out.println("******************");
		
		return this.best_solution.getCromosoma();
	}
	//-----------------------------------------------------------------------------------------------------
	public int getPopulation_size() {
		return population_size;
	}
	public void setPopulation_size(int population_size) {
		this.population_size = population_size;
	}
	public ArrayList<Carico> getPopolazione() {
		return popolazione;
	}
	public void setPopolazione(ArrayList<Carico> popolazione) {
		this.popolazione = popolazione;
	}
	public int getGenerazione() {
		return generazione;
	}
	public void setGenerazione(int generazione) {
		this.generazione = generazione;
	}
	public Carico getBest_solution() {
		return best_solution;
	}
	public void setBest_solution(Carico best_solution) {
		this.best_solution = best_solution;
	}
	public ArrayList<Double> getList_of_solutions() {
		return list_of_solutions;
	}
	public void setList_of_solutions(ArrayList<Double> list_of_solutions) {
		this.list_of_solutions = list_of_solutions;
	}
	
	

}
